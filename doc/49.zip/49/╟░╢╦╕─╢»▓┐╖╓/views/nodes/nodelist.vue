<template>
  <div>
     nodes 列表
  </div>
</template>
<script>
  export default {
    data(){
      return {

      }
    }
  }
</script>
