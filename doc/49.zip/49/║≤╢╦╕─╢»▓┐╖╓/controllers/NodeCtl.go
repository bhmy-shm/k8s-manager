package controllers

import "github.com/shenyisyn/goft-gin/goft"

type NodeCtl struct {
}

func(this *NodeCtl)  Build(goft *goft.Goft){

}
func(*NodeCtl) Name() string{
	return "NodeCtl"
}