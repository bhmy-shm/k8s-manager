package models
type NodeModel struct {
	Name string
	IP string
	HostName string
	Lables []string //标签
	CreateTime string

}
