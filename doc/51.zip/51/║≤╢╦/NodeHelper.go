package helpers

import (
	"fmt"
	"regexp"
)

const hostPattern="[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+\\.?"
func showLable(key string ) bool{
	return !regexp.MustCompile(hostPattern).MatchString(key )
}
//过滤 要显示的标签
func FilterLables(labels map[string]string) (ret []string){
  for k,v:=range labels{
  		if showLable(k){
			ret=append(ret,fmt.Sprintf("%s=%s",k,v))
		}
  }
  return
}