package models
type NodeModel struct {
	Name string
	IP string
	HostName string
	CreateTime string
}
