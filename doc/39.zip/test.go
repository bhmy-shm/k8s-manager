package main

import (
	"context"
	"fmt"
	"io"
	"k8s.io/api/core/v1"
	"k8sapi/src/configs"
)
func main() {
    client:= configs.NewK8sConfig().InitClient()

    req:=client.CoreV1().Pods("default").GetLogs("nginx-7875f55f56-5qqbr",
    	&v1.PodLogOptions{Follow:true })
    reader,_:=req.Stream(context.Background())
    for{
    	buf:=make([]byte,1024)
		n,err:=reader.Read(buf)
		if err!=nil && err!=io.EOF{
			break
		}
		fmt.Println(string(buf[0:n]))
	}



}