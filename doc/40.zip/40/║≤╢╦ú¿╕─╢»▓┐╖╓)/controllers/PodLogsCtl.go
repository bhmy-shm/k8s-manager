package controllers

import (
	"github.com/gin-gonic/gin"
	"github.com/shenyisyn/goft-gin/goft"
	"k8s.io/api/core/v1"
	"k8s.io/client-go/kubernetes"
)

type PodLogsCtl struct {
	Client *kubernetes.Clientset  `inject:"-"`
}

func NewPodLogsCtl() *PodLogsCtl {
	return &PodLogsCtl{}
}
func(this *PodLogsCtl) GetLogs(c *gin.Context) goft.Json{
	ns:=c.DefaultQuery("ns","default")
	podname:=c.DefaultQuery("podname","")
	cname:=c.DefaultQuery("cname","")
	req:=this.Client.CoreV1().Pods(ns).GetLogs(podname,&v1.PodLogOptions{Container:cname})
	ret:=req.Do(c)
	b,err:=ret.Raw()
	goft.Error(err)
	return gin.H{
		"code":20000,
		"data":string(b),
	}
}
func(*PodLogsCtl)  Name() string{
	 return "PodLogsCtl"
}

func(this *PodLogsCtl)  Build(goft *goft.Goft){
	 goft.Handle("GET","/pods/logs",this.GetLogs )
}
