package models

type ContainerModel struct {
	Name string
}
