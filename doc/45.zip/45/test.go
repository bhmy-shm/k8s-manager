package main

import (
	"github.com/gin-gonic/gin"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/tools/clientcmd"
	"k8s.io/client-go/tools/remotecommand"
	"k8sapi/src/helpers"
	"k8sapi/src/wscore"
	"log"
)



func main() {
	config, err := clientcmd.BuildConfigFromFlags("","config" )
	if err!=nil{
		log.Fatal(err)
	}
	config.Insecure=true
	client,err:=kubernetes.NewForConfig(config)
	if err!=nil{
		log.Fatal(err)
	}

	r:=gin.New()
	r.GET("/", func(c *gin.Context) {
		wsClient,err:=wscore.Upgrader.Upgrade(c.Writer,c.Request,nil)
		if err!=nil {
			return
		}
		shellClient:=wscore.NewWsShellClient(wsClient)
		err=helpers.HandleCommand(client,config,[]string{"sh"}).
			Stream(remotecommand.StreamOptions{
				Stdin:shellClient,
				Stdout:shellClient,
				Stderr:shellClient,
				Tty:true,
			})
		if err!=nil {
			log.Println(err)
		}

	})
	r.Run(":8080")
}