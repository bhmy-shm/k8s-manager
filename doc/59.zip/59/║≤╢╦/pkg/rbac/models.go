package rbac
type RoleModel struct {
	Name string
	NameSpace string
	CreateTime string
}


