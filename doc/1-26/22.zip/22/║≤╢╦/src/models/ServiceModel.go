package models
type ServiceModel struct {
	Name string
	NameSpace string
	CreateTime string
}
