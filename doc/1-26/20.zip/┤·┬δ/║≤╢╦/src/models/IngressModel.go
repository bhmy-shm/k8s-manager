package models
type IngressModel struct {
	Name string
	NameSpace string
	CreateTime string
}