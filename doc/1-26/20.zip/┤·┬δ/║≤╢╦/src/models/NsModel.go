package models

type NsModel struct {
	Name string
}
