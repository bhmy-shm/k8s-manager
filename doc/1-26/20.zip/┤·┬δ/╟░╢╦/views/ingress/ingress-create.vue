<template>
  <div>
    创建ingress
  </div>
</template>
