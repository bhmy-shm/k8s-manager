package main

import (
	"context"
	"fmt"
	"k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8sapi/src/configs"
	 "log"
)

func main() {

	client:=configs.NewK8sConfig().InitClient()
	IIngress:=client.NetworkingV1beta1().Ingresses("default")
	list,err:=IIngress.List(context.Background(),v1.ListOptions{})
	if err!=nil{
		log.Fatal(err)
	}
	for _,item:=range list.Items{
		fmt.Println(item.Name)
	}
}