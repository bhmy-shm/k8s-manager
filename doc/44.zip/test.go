package main

import (
	"github.com/gin-gonic/gin"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/tools/clientcmd"
	"k8s.io/client-go/tools/remotecommand"
	"k8sapi/src/helpers"
	"log"
	"os"
	"strings"
)

func main() {
	config, err := clientcmd.BuildConfigFromFlags("","config" )
	if err!=nil{
		log.Fatal(err)
	}
	config.Insecure=true
	client,err:=kubernetes.NewForConfig(config)
	if err!=nil{
		log.Fatal(err)
	}

	r:=gin.New()
	r.POST("/", func(c *gin.Context) {
		body,_:=c.GetRawData() //获取body 原始内容
		cmd:=strings.Split(string(body)," ")
		err=helpers.HandleCommand(client,config,cmd).Stream(remotecommand.StreamOptions{
			Stdout:c.Writer,
			Stderr:os.Stderr,
			Tty:true,
		})
	})
	r.Run(":8080")
}